#!/bin/bash
#Author: Gowri Sankar Marepalli
#Purpuse: Reading input from the table
#usage: sh filename.sh or ./filename.sh 

file=005_variable.sh
if [ -f $file ]; then 
	echo "file exist"
fi

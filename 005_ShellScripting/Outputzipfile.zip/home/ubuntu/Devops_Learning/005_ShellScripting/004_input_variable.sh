#!/bin/bash
#Author: Gowri Sankar Marepalli
#Purpuse: Getting input from the user
#usage: sh filename.sh value1 value2 or ./filename.sh value1 value2

echo "This is the first value I got: $1"
echo "This is the seconf value I got: $2"

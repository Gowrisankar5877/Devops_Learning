#!/bin/bash
#Author: Gowri Sankar Marepalli
#Purpose: Learning functions
#usage: ./Filename.sh or sh Filename.sh

function hello {
	echo "Hello World"

}
hello

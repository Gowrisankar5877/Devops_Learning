#!/bin/sh
#Author: Gowri Sankar Marepalli
#Purpose: printing fun using shell scripting
#usage: ./Filename.sh or sh Filename.sh

echo "Enter the message you want print"
read -r message
echo "Message is" $message

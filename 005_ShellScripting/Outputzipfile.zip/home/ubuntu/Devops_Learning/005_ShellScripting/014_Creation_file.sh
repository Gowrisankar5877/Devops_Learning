#!/bin/bash
#Author: Gowri Sankar Marepalli
#Purpose: creation of file
#Usage: sh Filename.sh or ./filename.sh

touch file1.txt
This folder consists of all shell scripting codes and files

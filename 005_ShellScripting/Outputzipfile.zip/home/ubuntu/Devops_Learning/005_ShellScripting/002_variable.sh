#!/bin/bash
#Author: Gowri Sankar Marepalli
#Purpose: Learning Variables
#Usage: sh Filename.sh or ./filename.sh
var1=10
var2='Hello'
echo "Today is ${var1} day, $var2 from me "
echo 'is it time to have lunch?'
echo "Time and date are displayed `date`"
echo 'This command does not support variables ${var1}'
